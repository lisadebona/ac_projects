<svg enable-background="new 0 0 412.2 55.6" version="1.1" viewBox="0 0 412.2 55.6" xml:space="preserve" xmlns="http://www.w3.org/2000/svg">
	<path class="st0" d="m27.3 0.9"/>
	<polygon class="st0" points="412.2 55.6 0 55.6 0 1.1 24.3 1.1 44.4 37.1 64.1 0.7 412.2 1.1"/>
	<polygon class="st1" points="24.9 0.1 44.3 35.6 63.5 0.1"/>
	<polyline class="st2" points="0 0.9 24.3 0.9 44.3 37.4 64.1 0.9 412.2 0.8"/>
	<line class="st3" x1="44.4" x2="44.3" y1="50.2" y2="36.2"/>
	<circle class="st4" cx="44.5" cy="51.7" r="2.2"/>
</svg>

