<svg enable-background="new 0 0 412.2 55.3" version="1.1" viewBox="0 0 412.2 55.3" xml:space="preserve" xmlns="http://www.w3.org/2000/svg">
	<path class="st0" d="m27.3 0.9"/>
	<polygon class="st1" points="68.9 0 26.8 0 48.7 31"/>
	<polygon class="st0" points="412.2 55.6 0 55.6 0 1.1 30.1 1.1 49 31.2 66.5 0.7 412.2 1.1"/>
	<path class="st1" d="m68.5 0.7"/>
	<polyline class="st2" points="0 0.9 30 0.9 48.8 31.2 67 0.9 412.2 0.8"/>
	<line class="st3" x1="48.7" x2="48.8" y1="45" y2="31.2"/>
	<circle class="st4" cx="48.7" cy="46.7" r="2.2"/>
</svg>
